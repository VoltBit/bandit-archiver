import java.io.File;
import java.util.List;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Reflection;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class ArchiveGUI extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	private static void configureFileChooser(final FileChooser fileChooser, File fileName ) {
		fileChooser.setTitle("View files");
		if ( fileName == null )
			fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		else{
			/**
			 * to solve : file chooser doesn't open archives
			 */
			File file = new File(System.getProperty("user.home"), "/arhiva.zip");
			System.out.println(file);
			fileChooser.setInitialFileName(file.getAbsolutePath());
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("codebandiTAR");

		BorderPane bp = new BorderPane();
		bp.setPadding(new Insets(10, 50, 50, 50));

		// Adding HBox
		HBox hb = new HBox();
		hb.setPadding(new Insets(20, 20, 20, 30));

		// Adding GridPane
		GridPane gridPane = new GridPane();
		gridPane.setPadding(new Insets(20, 20, 20, 20));
		gridPane.setHgap(5);
		gridPane.setVgap(5);

		// Implementing Nodes for GridPane
		Label lblUserName = new Label("File SRC");
		final TextField txtUserName = new TextField();

		Label lblPassword = new Label("File DST");
		final PasswordField pf = new PasswordField();

		Button btnLogin = new Button("Save");
		final Label lblMessage = new Label();

		Button addFileButton = new Button("Add file");

		// Adding Nodes to GridPane layout
		gridPane.add(lblUserName, 0, 0);
		gridPane.add(txtUserName, 1, 0);
		gridPane.add(lblPassword, 0, 1);
		gridPane.add(pf, 1, 1);
		gridPane.add(btnLogin, 2, 1);
		gridPane.add(lblMessage, 1, 2);
		gridPane.add(addFileButton, 2, 0);

		final FileChooser fileChooser = new FileChooser();
		
		/**
		 * Opens new file viewer
		 * Returns list of files chosen
		 * Can be sent to the Archive to be compressed
		 */
		addFileButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				configureFileChooser(fileChooser,null);
				List<File> list = fileChooser.showOpenMultipleDialog(primaryStage);
				if (list != null) {
					for (File file : list) {
						// actually send to archiver but w/e
						System.out.println("Chosen file:" + file);
					}
				}
			}
		});

		// load archive to list files
		Label lblArchive = new Label("Archive SRC");
		Button openArchive = new Button("Open Archive");
		final TextField txtArchiveOpen = new TextField();
		
		/**
		 * Opens archive for file selection
		 * File can be removed 
		 */
		openArchive.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				configureFileChooser(fileChooser,new File("ceva"));
				List<File> list = fileChooser.showOpenMultipleDialog(primaryStage);
				if (list != null) {
					for (File file : list) {
						// actually send to archiver but w/e
						System.out.println("Chosen file:" + file);
					}
				}
			}
		});

		gridPane.add(lblArchive, 0, 3);
		gridPane.add(txtArchiveOpen, 1, 3);
		gridPane.add(openArchive, 2, 3);

		// separator
		final Separator sepHor = new Separator();
		sepHor.setValignment(VPos.CENTER);
		GridPane.setConstraints(sepHor, 0, 2);
		GridPane.setColumnSpan(sepHor, 12);
		gridPane.getChildren().add(sepHor);

		GridPane checkboxGridPane = new GridPane();
		checkboxGridPane.setPadding(new Insets(20, 20, 20, 20));
		checkboxGridPane.setHgap(5);
		checkboxGridPane.setVgap(5);

		// CHECKBOXESSSS
		CheckBox cb1 = new CheckBox("arch_file1");
		CheckBox cb2 = new CheckBox("arch_file2");
		CheckBox cb3 = new CheckBox("arch_file3");

		Button rmFromArchive = new Button("Remove from archive");

		checkboxGridPane.add(cb1, 0, 0);
		checkboxGridPane.add(cb2, 0, 1);
		checkboxGridPane.add(cb3, 0, 2);
		checkboxGridPane.add(rmFromArchive, 2, 1);

		gridPane.add(checkboxGridPane, 0, 5);

		//////////// end FILES rm
		GridPane addFilesPane = new GridPane();
		addFilesPane.setPadding(new Insets(20, 20, 20, 20));
		addFilesPane.setHgap(5);
		addFilesPane.setVgap(5);

		// CHECKBOXESSSS
		CheckBox cb4 = new CheckBox("arch_file1");
		CheckBox cb5 = new CheckBox("arch_file2");
		CheckBox cb6 = new CheckBox("arch_file3");

		Button addToArchive = new Button("Add file to archive");

		addFilesPane.add(cb4, 0, 0);
		addFilesPane.add(cb5, 0, 1);
		addFilesPane.add(cb6, 0, 2);
		addFilesPane.add(addToArchive, 2, 1);

		gridPane.add(addFilesPane, 2, 5);
		/////////// end FILES add
		// separator
		final Separator sepHorNext = new Separator();
		sepHorNext.setValignment(VPos.CENTER);
		GridPane.setConstraints(sepHorNext, 0, 4);
		GridPane.setColumnSpan(sepHorNext, 12);
		gridPane.getChildren().add(sepHorNext);

		// Reflection for gridPane
		Reflection r = new Reflection();
		r.setFraction(0.7f);
		gridPane.setEffect(r);

		// DropShadow effect
		DropShadow dropShadow = new DropShadow();
		dropShadow.setOffsetX(5);
		dropShadow.setOffsetY(5);

		// Adding text and DropShadow effect to it
		Text text = new Text("codebandiTAR");
		text.setFont(Font.font("Calibri", FontWeight.BOLD, 28));
		text.setEffect(dropShadow);

		// Adding text to HBox
		hb.getChildren().add(text);

		// Add ID's to Nodes
		bp.setId("bp");
		gridPane.setId("root");
		checkboxGridPane.setId("checkList");
		addFilesPane.setId("addPane");
		btnLogin.setId("btnLogin");
		addFileButton.setId("testButton");
		openArchive.setId("archiveButton");
		txtArchiveOpen.setId("archiveTxt");
		text.setId("text");

		// Add HBox and GridPane layout to BorderPane Layout
		bp.setTop(hb);
		bp.setCenter(gridPane);

		// Adding BorderPane to the scene and loading CSS
		Scene scene = new Scene(bp);
		scene.getStylesheets().add(getClass().getClassLoader().getResource("login.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.titleProperty()
				.bind(scene.widthProperty()
						.asString()
						.concat(" : ")
						.concat(scene.heightProperty().asString()));
		// primaryStage.setResizable(false);
		primaryStage.show();
	}
}
