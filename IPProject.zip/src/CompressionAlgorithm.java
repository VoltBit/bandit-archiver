import java.io.File;

public abstract class CompressionAlgorithm {
	
	abstract File compressFile(File toCompress);
	
}
