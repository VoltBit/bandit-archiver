import java.io.File;
import java.util.List;


public interface ArchiveInterface {
	
	public File archiveFiles(List<File> files);
	public boolean removeFromArchive(File archive , File toRemove);
	public boolean addToArchive(File archive, File toAdd);
	
}
