import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class Archive implements ArchiveInterface{
	private static CompressionAlgorithm algorithm;
	
	Archive(CompressionAlgorithm algorithm){
		this.algorithm = algorithm;
	}
	
	@Override
	public File archiveFiles(List<File> files) {
		// TODO Auto-generated method stub
		List<File> compressedFiles = new LinkedList<>();
		
		for ( File file : files )
			compressedFiles.add(algorithm.compressFile(file));
		
		// compress all into one ? idk
		
		return null;
	}

	@Override
	public boolean removeFromArchive(File archive, File toRemove) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addToArchive(File archive, File toAdd) {
		// TODO Auto-generated method stub
		return false;
	}

}
